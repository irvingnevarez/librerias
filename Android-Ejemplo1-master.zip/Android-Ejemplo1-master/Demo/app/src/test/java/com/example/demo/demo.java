package com.example.demo;

import android.hardware.camera2.CameraCharacteristics;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import org.junit.runner.notification.Failure;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.IClass;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.Key;
import java.util.List;
import java.util.Set;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;

public class demo {
    ExtentHtmlReporter REPORTE1 = new ExtentHtmlReporter("C:/Users/Contractor/AndroidStudioProjects/Demo/Reporte/Learn2.html"); //Instancia, ubicación y nombre que llevará le Reporte

    ExtentReports extent = new ExtentReports();  // Creación de extent report.
    ExtentTest logger1;

    public ExtentReports getExtend1() { // Método para llevarlo a diferentes Test.
        return extent;

    }

    public AndroidDriver<MobileElement> driver;  //Driver android  publico.
    // WebDriver driver;
    public WebDriverWait wait;


    @BeforeTest
    //Testng, Se cargara antes del Test lo siguiente.
    public void setup() throws MalformedURLException {                                //Método para hacer conexión con el dispositivo móvil.
        DesiredCapabilities caps = new DesiredCapabilities();                          // LLamado de capabilities


        caps.setCapability("deviceName", "Galaxy Nexus API 24");      // Se asigna el nombre del dispositivo.
        caps.setCapability("udid", "emulator-5554");                  // Su Nombre que aparece desde el cmd con adb devices.
        caps.setCapability("platformName", "Android");                // Plataforma.
        caps.setCapability("platformVersion", "7.0");                 //Version de Android.
        caps.setCapability("skipUnlock", "true");                     //Mantener desbloqueado.
        caps.setCapability("appPackage", "com.google.android.deskclock"); //En que Aplicación se Abrira (Se obtiene con el emulador en la app y el cmd adb shell y despues dumpsys window windows | grep -E 'mCurrentFocus').
        caps.setCapability("appActivity", "com.android.deskclock.DeskClock"); //En que Actividad.
        caps.setCapability("noReset", "false");
        driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps); //Implementacion del servidor appium en el driver.
        wait = new WebDriverWait(driver, 10);                             //Tiempo en el cual esperara.

    }

    @Test(priority = 0)
        //Inicio del Test con mayor Prioridad.
    void Termometro() {
        //  ExtentReports extent = new ExtentReports();
        getExtend1().attachReporter(REPORTE1); //Implementación del Método getExtend1() con el REPORTE1.
        // call createTest method and pass the name of TestCase- Based on your requirement

        // call createTest method and pass the name of TestCase- Based on your requirement
        ExtentTest logger = extent.createTest("Termometro");
        //Click and pass Splash
        try {
            driver.findElement(By.xpath("//android.widget.ImageView[@content-desc='Stopwatch']")).click(); //Encuentra el icono  y le da clic.


            logger.log(Status.PASS, "se ingreso a termometro");                                   //si se logro hacerlo aparece lo siguiente
            extent.flush();
        } catch (Exception e) {
            logger.log(Status.FAIL, " NO se ingreso a termometro");                                // No se logro hacer entra en el catch con el mensaje
            extent.flush();
        }
    }

    @Test(priority = 1)
    void versionAndroid() throws IOException {                                                            //Segundo Test.
        //  ExtentReports extent = new ExtentReports();
        getExtend1().attachReporter(REPORTE1);                                                           //Metodo para extent.

        logger1 = extent.createTest("version Android");                                          //Nombre del Test.

        try {
            driver.navigate().back();                                                                         // Regresar del Reloj.

            // driver.findElement(By.xpath("//android.widget.ImageView[@content-desc=\"More options\"]")).click();
            driver.findElement(By.xpath("//android.widget.TextView[@content-desc='Apps']")).click();//           //Entrar a Aplicaciones.

            driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"Settings\"]")).click();       //Entrar a Settings.
            //Click and pass Splash
            // driver.findElement(By.className("setting android.widget.RelativeLayout")).click();
            // driver.findElement(By.id("com.android.settings:id/content_frame")).click();//setting android.widget.RelativeLayout
            //  driver.findElement(By.id("d6daca2c-f682-4446-a827-f7b3a221e20a")).click();// v android
            //   driver.findElement(By.className("android.widget.RelativeLayout")).click();

            logger1.log(Status.PASS, "se ingreso a Settings ");                                                //Mensaje.
            logger1.pass("", MediaEntityBuilder.createScreenCaptureFromPath("logger1pass.jpg").build());    //screenshot

            extent.flush();                                                                                       //"Agregar" a extend.
        } catch (Exception e) {

            logger1.log(Status.FAIL, " No se ingreso a Settings ");                                       //Mensaje de Catch.


            logger1.fail("", MediaEntityBuilder.createScreenCaptureFromPath("logger1.png").build());    // Screenshot.
            // logger1.addScreenCaptureFromPath("/Users/Contractor/AndroidStudioProjects/Demo/Reporte/logger1.png");
            extent.flush();                                                                                      //Agregar a extent.

        }

    }
    /*  @AfterMethod
   public void tearDown(ITestResult result) throws IOException
    {

        if(result.getStatus()==ITestResult.FAILURE)
        {
            String temp=Utility.getScreenshot(driver);

            logger1.fail(result.getThrowable().getMessage(), MediaEntityBuilder.createScreenCaptureFromPath(temp).build());
            logger1.addScreenCaptureFromPath(temp);
        }
        extent.flush();
        driver.quit();
}*/
}