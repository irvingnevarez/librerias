package com.example.demo;

import org.apache.poi.xwpf.usermodel.XWPFRun;

public class MetodosWord {
    public static void saltodeLinea(XWPFRun run, int saltos) {
        for(int i = 0; i<saltos; i++) {
            run.addBreak();
        }
    }
}
