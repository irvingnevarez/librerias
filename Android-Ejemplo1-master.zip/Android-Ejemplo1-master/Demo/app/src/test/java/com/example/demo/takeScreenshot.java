package com.example.demo;

import java.io.File;
import java.io.IOException;

public class takeScreenshot {
  /*  public static void screen( String numero) throws  AWTException, IOException {
        Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
        BufferedImage capture = new Robot().createScreenCapture(screenRect);
        ImageIO.write(capture, "jpg", new File( "C:/Users/Contractor/Desktop/image/cp-correoPASO"+numero+".jpg"));
        //  ImageIO.write(capture, "jpg", new File("C:/SShot.jpg"));
    }*/
}
